package com.ng.workflow;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class CalculateInterestService implements JavaDelegate {

	private static final Logger LOGGER = LoggerFactory.getLogger(CalculateInterestService.class);

	@Override
	public void execute(DelegateExecution execution) {

		Long s = (Long) execution.getVariable("amount");
		LOGGER.info("amount is "+s);
		long r =1; // one month interest
		long t = 36 * 12; // one month period
		long emi = s * r * t ;
		LOGGER.info("amount is "+s+" r "+r+" t "+t);
		/*
		 * long emi = (long) ((s * r * (float)Math.pow(1 + r, t)) / (float)(Math.pow(1 +
		 * r, t) - 1));
		 */
		execution.setVariable("value", emi);
		LOGGER.info("calculating emi of the loan per month with 12% interest for 3years  is " + emi);
	}

}
