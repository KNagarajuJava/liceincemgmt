package com.knr.ps.api.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.knr.ps.api.entity.Payment;
import com.knr.ps.api.repository.PaymentRepository;

@Service
public class PaymentService {
    
    @Autowired
    private PaymentRepository repository;
    
    Logger logger= LoggerFactory.getLogger(PaymentService.class);
    private final RestTemplate restTemplate;
    
    @Value("${service.encdec.url}") // Injecting Service encrpt endpoint  URL from application.properties
    private String serviceEncdecUrl;

    public PaymentService(RestTemplateBuilder restTemplateBuilder) {
        this.restTemplate = restTemplateBuilder.build();
    }

   
    public Payment doPayment(Payment payment) throws JsonProcessingException {
		// Encryption Transaction details by calling encrpt endpoint
    	
		Map<String, String> requestBody = new HashMap<>();
		//setting request body as parameters to api 
		requestBody.put("applicationName", "PaymentStatus");
		requestBody.put("key", payment.getTransactionId());

		// Setting headers
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.setAccept(MediaType.parseMediaTypes("*/*"));

		// Creating HTTP request entity
		HttpEntity<Map<String, String>> requestEntity = new HttpEntity<>(requestBody, headers);
		// Making the POST call to encreypt decrypt api endpoint to encrypt the
		// transactions details for payment
		ResponseEntity<String> response = restTemplate.exchange(serviceEncdecUrl, HttpMethod.POST, requestEntity,
				String.class);
		logger.info("encryption data --> " + response.getBody());
		payment.setPaymentStatus(paymentProcessing());
		payment.setTransactionId(response.getBody());
		logger.info("Payment-Service Request : {}", new ObjectMapper().writeValueAsString(payment));
		return repository.save(payment);
    }


    public String paymentProcessing(){
        //api should be 3rd party payment gateway (paypal,paytm...)
        return new Random().nextBoolean()?"success":"false";
    }


    public Payment findPaymentHistoryByOrderId(int orderId) throws Exception {
        Payment payment=repository.findByOrderId(orderId);
        logger.info("paymentService findPaymentHistoryByOrderId : {}",new ObjectMapper().writeValueAsString(payment));
        return payment ;
    }
}
