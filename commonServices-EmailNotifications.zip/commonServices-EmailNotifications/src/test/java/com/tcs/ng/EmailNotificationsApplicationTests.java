package com.tcs.ng;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailNotificationsApplicationTests {

	@Test
	void contextLoads() {
	}

}
