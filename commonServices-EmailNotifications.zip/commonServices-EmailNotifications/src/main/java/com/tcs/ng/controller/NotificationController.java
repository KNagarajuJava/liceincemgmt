package com.tcs.ng.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tcs.ng.pojo.EmailRequest;
import com.tcs.ng.service.EmailService;

@RestController
public class NotificationController {
	Logger log = LoggerFactory.getLogger(NotificationController.class);
	@Autowired
	private EmailService emailService;

	@PostMapping(value = "/send-email", consumes = "application/json")
	public String sendmail(@RequestBody EmailRequest emailRequest) {
	
			log.info("-------start sendmail method --------");
			String to = emailRequest.getTo();
			String subject = emailRequest.getSubject();
			String body = emailRequest.getBody();
			String status=emailService.sendEmail(to, subject, body);
			log.info("-------sendmail method end --------");
			if(status.equals("Success")) {
			return "Email sent successfully to :: "+emailRequest.getTo();
			}else
			return ""+status;
		}
		
	}