package com.example.demo.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.registerDetails;
import com.example.demo.service.registerCsService;
import com.example.demo.service.userService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.twitter.zipkin.thriftjava.Response;

@RestController
public class resgisterCsController {

	private registerCsService registerService;
	
	public resgisterCsController(registerCsService registerService,userService userService) {
		super();
		this.registerService = registerService;
	}
	
	@PostMapping("/createEnv")
	public ObjectNode createApplication(@RequestBody registerDetails details) throws IOException {
		String res = registerService.createApplication(details);
	    
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode jsonResponse = mapper.createObjectNode();
        
        ObjectNode data = mapper.createObjectNode();
        data.put("token", res);
        
        jsonResponse.set("data", data);
        jsonResponse.put("message", "token generated successfully");
        jsonResponse.put("status", "SUCCESS");
        
        return jsonResponse;
	}
	
	@PutMapping("/updateApplication")
	public String updateApplication(@RequestBody registerDetails details) throws IOException {
		details.setToken("token");
		return registerService.updateApplication(details);
	}
	
	@DeleteMapping("/deleteApplication/{id}")
	public String deleteApplication(@PathVariable int id) {
		return registerService.deleteApplication(id);
	}
	
	@GetMapping("/getApplicationById/{id}")
	public Optional<registerDetails> getApplicationById(@PathVariable int id) {
		return registerService.getAllApplicationsDetailsById(id);
	}
	@GetMapping("/getAllApplications")
	public List<registerDetails> getAllApplications() {
		return registerService.getAllApplicationsDetails();
	}
	
	@GetMapping("/getTokenByApplicationName")
	private String getTokenByApplicationName(@RequestParam String appName) {
		return registerService.getTokenByApplicationName(appName);
	}
}
