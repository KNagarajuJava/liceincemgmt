package com.tcs.nk;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
@RequestMapping("/api/auth")
public class GenerateTocken {
	
	@Autowired
	TokenService tokenService;
	
	@GetMapping("/getToken")
	private String getToken() throws Exception {
		return tokenService.generateToken();
	}
	@PostMapping(value = "/getCode", consumes = "application/json")
	private String getToken(@RequestBody UserDetails user) throws Exception {
	
		return tokenService.generateToken(user) != null?tokenService.generateToken(user):"not a valid details";
	}
	
	@GetMapping("/hi")
	private String hello() throws Exception {
		return tokenService.hello();
	}	

}
