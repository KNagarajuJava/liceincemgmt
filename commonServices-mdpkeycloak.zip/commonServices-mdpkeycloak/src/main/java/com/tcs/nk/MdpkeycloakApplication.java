package com.tcs.nk;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdpkeycloakApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdpkeycloakApplication.class, args);
	}

}
