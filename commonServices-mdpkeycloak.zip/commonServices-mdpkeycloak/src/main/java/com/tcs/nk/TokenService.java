package com.tcs.nk;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Service
public class TokenService {
	Logger log = LoggerFactory.getLogger(TokenService.class);
//	@Value("${keycloak_host}")
	private String keycloak_host="10.63.34.245";
	//@Value("${keycloak_host}")
	private String keycloak_port="8080";
	
	public String generateToken() throws Exception {
		log.info("====generateToken=============");
		OkHttpClient client = new OkHttpClient().newBuilder().build();
		MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
		RequestBody body = RequestBody.create(
				"client_id=mdp_pe&username=" + "markmark" + "&password=" + "tcs@12345" + "&grant_type=password",
				mediaType);
		Request request = new Request.Builder()
				.url("http://"+keycloak_host+":"+keycloak_port+"/realms/mdp/protocol/openid-connect/token").method("POST", body)
				.addHeader("Content-Type", "application/x-www-form-urlencoded").build();
		
		
		System.out.println(request.toString());
		log.info("====request =============:: "+request);
		Response response = client.newCall(request).execute();
		ObjectMapper mapper = new ObjectMapper();
		JsonNode objectNode = mapper.readTree(response.body().string());
		log.info("====end ============="+response);
		return objectNode.get("access_token").asText();
	}

	public String hello() {
		log.info("hello method");
		return "hi hello ";
	}

	public String generateToken(UserDetails user) {
		log.info("====service:: generateToken=============:: "+user);
		OkHttpClient client = new OkHttpClient().newBuilder().build();
		MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
		RequestBody body = RequestBody.create(
				"client_id=mdp_pe&username=" + user.getUsername() + "&password=" + user.getPassword() + "&grant_type=password",
				mediaType);
		Request request = new Request.Builder()
				.url("http://"+keycloak_host+":"+keycloak_port+"/realms/mdp/protocol/openid-connect/token").method("POST", body)
				.addHeader("Content-Type", "application/x-www-form-urlencoded").build();
		String status=null;
		
		System.out.println(request.toString());
		try {
			log.info("====request =============:: "+request);
			Response response = client.newCall(request).execute();
			ObjectMapper mapper = new ObjectMapper();
			JsonNode objectNode  = mapper.readTree(response.body().string());
			status=objectNode.get("access_token").asText();
			
			log.info("=============end ============="+response);
		} catch (Exception e) {
			System.err.println(e);
		}
		
		return status;
	}
}
