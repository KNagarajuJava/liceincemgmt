package com.example.demo.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import com.example.demo.entity.UserDetails;
import com.example.demo.entity.RegisterDetails;
import com.example.demo.entity.registerUser;

public interface registerCsService {

	RegisterDetails createUser(RegisterDetails details) throws Exception;

	List<RegisterDetails> getAllUserDetails();

	RegisterDetails updateUser(RegisterDetails details) throws IOException;

	String deleteUser(int id);

	RegisterDetails getAllUserDetailsById(int id) throws Exception;

	String getTokenByUsername(String appName);


	RegisterDetails generateToken(UserDetails user);
}
