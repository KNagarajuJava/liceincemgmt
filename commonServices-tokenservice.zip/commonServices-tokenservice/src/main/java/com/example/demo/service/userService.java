package com.example.demo.service;

import java.io.IOException;

import com.example.demo.entity.RegisterDetails;

public interface userService {

	String generateToken() throws IOException;

	void createUser(RegisterDetails details,String token) throws IOException;

	String getApplicationId(String appName) throws IOException;

	void updateUser(int usrId, RegisterDetails details, String token) throws IOException;



}
