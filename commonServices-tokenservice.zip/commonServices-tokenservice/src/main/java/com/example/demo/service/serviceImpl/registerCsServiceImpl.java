package com.example.demo.service.serviceImpl;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.example.demo.entity.RegisterDetails;
import com.example.demo.entity.UserDetails;
import com.example.demo.exception.NoUserFoundException;
import com.example.demo.repository.registerDetailsRepository;
import com.example.demo.service.registerCsService;
import com.example.demo.service.userService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Service
public class registerCsServiceImpl implements registerCsService {

//	private String keycloak_host="keycloak.keycloak.svc.cluster.local";
//	private String keycloak_port="80";
	private String keycloak_host="10.63.16.153";
	private static final String TOKENURL = "http://10.63.16.153:8080/realms/mdp/protocol/openid-connect/token";
    private String keycloak_port="8080";
	Logger log = LoggerFactory.getLogger(registerCsServiceImpl.class);
	private registerDetailsRepository registerRepository;
	private userService userService;

	public registerCsServiceImpl(registerDetailsRepository registerRepository, userService userService) {
		super();
		this.registerRepository = registerRepository;
		this.userService = userService;

	}

	@Override
	public RegisterDetails createUser(RegisterDetails details) throws Exception {
		Optional<RegisterDetails> resdetail = registerRepository.findByUsername(details.getUsername());
		RegisterDetails user=null;
		if (resdetail.isEmpty()) {
			String token = userService.generateToken();
			userService.createUser(details, token);
			details.setToken(generateTokenForApplication(details));
		//	System.out.println("user status :"+stat);
		/*
		 * if(details.getRole()==
		 * null||details.getRole().isEmpty()||details.getRole().equals("")) {
		 * details.setRole("user");}
		 */
			try {
				user = registerRepository.save(details);
			} catch (Exception ex) {
				System.err.println("service :: "+ex.getMessage());
				throw new Exception();
			}
			//String tk=getTokenByUsername(user.getUsername());
		//	user.setToken(getTokenByUsername(user.getEmail()));
		}
		return user;
	}

	private String generateTokenForApplication(RegisterDetails details) throws IOException {
		System.out.println("<<<<---- generateTokenForApplication(RegisterDetails details) ::::    --->>> ");
		OkHttpClient client = new OkHttpClient().newBuilder().build();
		MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
		 String requestBodyContent = "client_id=mdp_pe" +
                 "&username=" + details.getEmail() +
                 "&password=" + details.getPassword() +
                 "&email=" + details.getEmail() +            // Adding the email field
                 "&grant_type=password";

         RequestBody body = RequestBody.create(requestBodyContent, mediaType);

         // Build the POST request
         Request request = new Request.Builder()
                 .url(TOKENURL)
                 .post(body)
                 .addHeader("Content-Type", "application/x-www-form-urlencoded")
                 .build();
		/*
		 * RequestBody body = RequestBody.create( "client_id=mdp_pe&username="
		 * +details.getUsername()+"&password="+details.getPassword()+"&email=" +
		 * details.getEmail()+"&grant_type=password", mediaType); Request request = new
		 * Request.Builder()
		 * .url("http://10.63.34.245:8080/realms/mdp/protocol/openid-connect/token").
		 * method("POST", body) .addHeader("Content-Type",
		 * "application/x-www-form-urlencoded").build();
		 * System.err.println(details.getUsername());
		 */
		System.err.println(request.toString());
		Response response = client.newCall(request).execute();
		System.err.println(response.toString());
		ObjectMapper mapper = new ObjectMapper();
		JsonNode objectNode = mapper.readTree(response.body().string());
		System.err.println(objectNode.get("access_token").asText());
		return objectNode.get("access_token").asText();
	}

	@Override
	public List<RegisterDetails> getAllUserDetails() {
		return registerRepository.findAll();
	}

	@Override
	public RegisterDetails updateUser(RegisterDetails details) throws IOException {
		//String username = details.getUsername();
		RegisterDetails res=null;
		//Optional<RegisterDetails> detail = registerRepository.findByUsername(username);
		Optional<RegisterDetails> detail = registerRepository.findById(details.getId());
		if (detail.isEmpty()) {
			throw new NoUserFoundException("No user with Name : " + details.getId());
		} else {
			int usrId =details.getId();
			String token = userService.generateToken();
			userService.updateUser(usrId,details, token);
			//registerRepository.deleteById(detail.get().getId());
			details.setToken(generateTokenForApplication(details));
			res=registerRepository.save(details);
			res.setToken(getTokenByUsername(details.getUsername()));
		}
		return res;
	}

	

	@Override
	public String deleteUser(int id) {
		registerRepository.deleteById(id);
		return "user Deleted Successfully";
	}

	@Override
	public RegisterDetails getAllUserDetailsById(int id) throws Exception{
		RegisterDetails details =  registerRepository.findById(id)
    .orElseThrow(() -> new NoUserFoundException("No user with ID: " + id));
return details;
	}

	@Override
	public String getTokenByUsername(String username) {
		Optional<RegisterDetails> detail = registerRepository.findByUsername(username);
		String status=null;
		if (detail.isEmpty()) {
			status ="no details wer found with this name  :: "+username;
		} else {
			
			status= detail.get().getToken();
		}
		return status;
	}
	@Override
	public RegisterDetails generateToken(UserDetails user) {
		Optional<RegisterDetails> detail = registerRepository.findByEmail(user.getUsername());
		log.info("====service:: generateToken=============:: "+user);
		OkHttpClient client = new OkHttpClient().newBuilder().build();
		MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
		RequestBody body = RequestBody.create(
				"client_id=mdp_pe&username=" + user.getUsername() + "&password=" + user.getPassword() + "&grant_type=password",
				mediaType);
		Request request = new Request.Builder()
				.url("http://"+keycloak_host+":"+keycloak_port+"/realms/mdp/protocol/openid-connect/token").method("POST", body)
				.addHeader("Content-Type", "application/x-www-form-urlencoded").build();
		String status=null;
		RegisterDetails registerDetails=null;
		System.out.println(request.toString());
		try {
			log.info("====request =============:: "+request);
			Response response = client.newCall(request).execute();
			ObjectMapper mapper = new ObjectMapper();
			JsonNode objectNode  = mapper.readTree(response.body().string());
			
			if (detail.isPresent()) {
			    registerDetails = detail.get();
			    status=objectNode.get("access_token").asText();
			    registerDetails.setToken(status);
			}
			log.info("=============end ============="+response);
		} catch (Exception e) {
			System.err.println(e);
		}
		return registerDetails; 
	}
}
