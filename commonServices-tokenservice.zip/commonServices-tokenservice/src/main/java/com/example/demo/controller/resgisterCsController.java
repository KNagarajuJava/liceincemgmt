package com.example.demo.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.RegisterDetails;
import com.example.demo.entity.UserDetails;
import com.example.demo.service.registerCsService;
import com.example.demo.service.userService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;

@RestController
@CrossOrigin
public class resgisterCsController {

	private registerCsService registerService;

	public resgisterCsController(registerCsService registerService, userService userService) {
		super();
		this.registerService = registerService;
	}

	@PostMapping("/createUser")
	public ObjectNode createUser(@RequestBody RegisterDetails details) {
		RegisterDetails res;
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode jsonResponse = mapper.createObjectNode();
		ObjectNode data = mapper.createObjectNode();
		try {
			res = registerService.createUser(details);
			if (res != null) {
				data.put("token", res.getToken());
				data.put("ID", res.getId());
				data.put("username", res.getUsername());
				data.put("fullname", res.getFullname());
				data.put("Email", res.getEmail());
				data.put("ContactNo", res.getContactNo());
				data.put("Organization", res.getOrganization());
				data.put("role", res.getRole());
				jsonResponse.set("data", data);
				jsonResponse.put("message", "token generated successfully");
				jsonResponse.put("status", "SUCCESS");
			} else {
				jsonResponse.put("message", "User name or email  already exist!!!");
			}
		} catch (Exception e) {
			data.put("name", details.getUsername());
			data.put("Email", details.getEmail());
			jsonResponse.set("data", data);
			jsonResponse.put("message", " Something went wrong please check user details !!!");
			jsonResponse.put("status", "Failed to create user");
		}

		return jsonResponse;
	}

	@PutMapping("/updateUser")
	public RegisterDetails updateUser(@RequestBody RegisterDetails details) throws IOException {
		details.setToken("token");
		return registerService.updateUser(details) != null ? registerService.updateUser(details) : null;
	}

	@DeleteMapping("/deleteUser/{id}")
	public String deleteUser(@PathVariable int id) {
		String result = registerService.deleteUser(id);
		return result != null ? result : "please check details ";
	}

	@GetMapping("/getUserById/{id}")
	public ObjectNode getUserById(@PathVariable int id) {
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode jsonResponse = mapper.createObjectNode();
		ObjectNode data = mapper.createObjectNode();
		try {
			RegisterDetails res = registerService.getAllUserDetailsById(id);
			data.put("token", res.getToken());
			data.put("ID", res.getId());
			data.put("username", res.getUsername());
			data.put("Email", res.getEmail());
			data.put("ContactNo", res.getContactNo());
			data.put("Organization", res.getOrganization());
			data.put("role", res.getRole());
			jsonResponse.set("data", data);
		} catch (Exception e) {
			jsonResponse.put("message", "No user found");
		}
		return jsonResponse;
	}

	@GetMapping("/getAllUsers")
	public List<RegisterDetails> getAllUsers() {
		List<RegisterDetails> allUserDetails = registerService.getAllUserDetails();

		return allUserDetails != null ? allUserDetails : null;
	}

	@GetMapping("/getTokenByUser")
	private String getTokenByUserName(@RequestParam String username) {
		String tokenByUsername = registerService.getTokenByUsername(username);
		return tokenByUsername != null ? tokenByUsername : "please check details";
	}

	@PostMapping(value = "/getCode", consumes = "application/json")
	private ObjectNode getToken(@RequestBody UserDetails user) throws Exception {
		RegisterDetails res = registerService.generateToken(user);
		ObjectMapper mapper = new ObjectMapper();
		ObjectNode jsonResponse = mapper.createObjectNode();
		ObjectNode data = mapper.createObjectNode();
		if (res != null) {
			data.put("token", res.getToken());
			data.put("ID", res.getId());
			data.put("username", res.getUsername());
			data.put("fullname", res.getFullname());
			data.put("Email", res.getEmail());
			data.put("ContactNo", res.getContactNo());
			data.put("Organization", res.getOrganization());
			data.put("role", res.getRole());
			jsonResponse.set("data", data);
		} else {
			jsonResponse.put("message", "Not a valid user");
		}
		return jsonResponse;
	}
}
