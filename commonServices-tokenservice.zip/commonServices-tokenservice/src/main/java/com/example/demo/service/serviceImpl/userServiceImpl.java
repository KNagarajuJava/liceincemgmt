package com.example.demo.service.serviceImpl;

import java.io.IOException;

import org.springframework.stereotype.Service;

import com.example.demo.entity.RegisterDetails;
import com.example.demo.service.userService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Service
public class userServiceImpl implements userService {

	private String keycloak_host="10.63.16.153";
        private String keycloak_port="8080";

	@Override
	public String generateToken() throws IOException {
		OkHttpClient client = new OkHttpClient().newBuilder().build();
		MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
		System.out.println("genetate tocken--------------");
		RequestBody body = RequestBody
				.create("client_id=security-admin-console&username=admin&password=admin&grant_type=password", mediaType);
		System.out.println("genetate tocken--------------");
		Request request = new Request.Builder()
				.url("http://10.63.16.153:8080/realms/master/protocol/openid-connect/token").method("POST", body)
				.addHeader("Content-Type", "application/x-www-form-urlencoded").build();
		System.out.println("genetate tocken--------------"+request.toString());
		Response response = client.newCall(request).execute();
		ObjectMapper mapper = new ObjectMapper();
		JsonNode objectNode = mapper.readTree(response.body().string());
		return objectNode.get("access_token").asText();
	}

	@Override
	public void createUser(RegisterDetails details, String token) throws IOException {
		OkHttpClient client = new OkHttpClient().newBuilder().build();
		MediaType mediaType = MediaType.parse("application/json");
		StringBuilder sb = new StringBuilder();
		/*
		 * sb.append("{ \\\"services\\\" : ["); for (String i : details.getServices()) {
		 * sb.append("\\\"" + i + "\\\","); } sb.deleteCharAt(sb.length() - 1);
		 * sb.append("] }");
		 */
		//MediaType mediaType = MediaType.parse("application/x-www-form-urlencoded");
		 String requestBodyContent = 
                "&username=" + details.getEmail() +
                "&password=" + details.getPassword() +
                "&email=" + details.getEmail() +            // Adding the email field
                "&grant_type=password";

			
			
			  RequestBody body = RequestBody.create("{\n    \"username\": \"" +
			  details.getEmail() +
			  "\",\n    \"enabled\": true,\n    \"attributes\": {\n      \"microservices\": \"\" ,\n      \"expiration_time\": \"2024-12-31T23:59:59Z\"\n    },\n    \"credentials\": [\n      {\n        \"type\": \"password\",\n        \"value\": \""
			  + details.getPassword() +
			  "\",\n        \"temporary\": false\n      }\n    ]\n  }", mediaType); Request
			  request = new
			  Request.Builder().url("http://"+keycloak_host+":"+keycloak_port+
			  "/admin/realms/mdp/users") .method("POST", body).addHeader("Content-Type",
			  "application/json") .addHeader("Authorization", "Bearer " + token).build();
			 
		/*
		 * RequestBody body = RequestBody.create("{\n" + "    \"username\": \"" +
		 * details.getEmail() + "\",\n" + "    \"enabled\": true,\n" +
		 * "    \"email\": \"" + details.getEmail() + "\",\n" + // Added email field
		 * "    \"attributes\": {\n" + "      \"microservices\": \"\", \n" +
		 * "      \"expiration_time\": \"2024-12-31T23:59:59Z\"\n" + "    },\n" +
		 * "    \"credentials\": [\n" + "      {\n" +
		 * "        \"type\": \"password\",\n" + "        \"value\": \"" +
		 * details.getPassword() + "\",\n" + "        \"temporary\": false\n" +
		 * "      }\n" + "    ]\n" + "  }", mediaType);
		 */

		/*
		 * Request request = new Request.Builder() .url("http://" + keycloak_host + ":"
		 * + keycloak_port + "/admin/realms/mdp/users") .method("POST", body)
		 * .addHeader("Content-Type", "application/json") .build();
		 */

		Response response = client.newCall(request).execute();
		System.out.println("Keycloak User Creation !!" + response.body().string());//"errorMessage":"User exists with same username"
		
	}

	public String getApplicationId(String appName) throws IOException {
		OkHttpClient client = new OkHttpClient().newBuilder().build();
		MediaType mediaType = MediaType.parse("text/plain");
		RequestBody body = RequestBody.create("", mediaType);
		Request request = new Request.Builder()
				.url("http://"+keycloak_host+":"+keycloak_port+"/admin/realms/mdp/users?username=" + appName).method("GET",null)
				.addHeader("Authorization", "Bearer " + generateToken()).build();
		Response response = client.newCall(request).execute();
		ObjectMapper mapper = new ObjectMapper();
		JsonNode objectNode = mapper.readTree(response.body().string());
		return objectNode.get(0).get("id").asText();
	}

	@Override
	public void updateUser(int usrId,RegisterDetails details, String token) throws IOException {

		OkHttpClient client = new OkHttpClient().newBuilder().build();
		MediaType mediaType = MediaType.parse("application/json");
		StringBuilder sb = new StringBuilder();
		/*
		 * sb.append("{ \\\"services\\\" : ["); for (String i : details.getServices()) {
		 * sb.append("\\\"" + i + "\\\","); } sb.deleteCharAt(sb.length() - 1);
		 * sb.append("] }");
		 */
		RequestBody body = RequestBody.create("{\n    \"firstName\": \"First Name\",\n    \"lastName\": \"Last Name\",\n    \"attributes\": {\n        \"microservices\":\"\n    }\n}",mediaType);
		String str = "{\n    \"firstName\": \"First Name\",\n    \"lastName\": \"Last Name\",\n    \"attributes\": {\n        \"microservices\":\""+ sb.toString() +"\"\n    }\n}";
		System.out.println(str);
		Request request = new Request.Builder()
				.url("http://"+keycloak_host+":"+keycloak_port+"/admin/realms/mdp/users/"+usrId)
				.method("PUT", body).addHeader("Content-Type", "application/json")
				.addHeader("Authorization",
						"Bearer "+ token)
				.build();
		Response response = client.newCall(request).execute();
	//	System.out.println("Update Successful");
	}

}
