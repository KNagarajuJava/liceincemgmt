package com.example.demo.repository;

import com.example.demo.entity.RegisterDetails;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface registerDetailsRepository extends JpaRepository<RegisterDetails,Integer>{

	
	Optional<RegisterDetails> findByUsername(String username);
	Optional<RegisterDetails> findByEmail(String email);


}
