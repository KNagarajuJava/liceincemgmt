package com.example.demo.entity;

import io.swagger.annotations.ApiModelProperty;
import java.time.LocalDate;
import java.util.List;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

//@Entity
//@Table(name="registerUser")
public class registerUser {
	/*
	 * @Id
	 * 
	 * @GeneratedValue(strategy = GenerationType.SEQUENCE)
	 * 
	 * @ApiModelProperty(hidden = true) private int id;
	 * 
	 * @Column(unique = true) private String username;
	 * 
	 * @Column private String password;
	 * 
	 * @Column private String email;
	 * 
	 * @Column private String contactNo;
	 * 
	 * @Column private String organization;
	 * 
	 * @Column(columnDefinition = "TEXT")
	 * 
	 * @ApiModelProperty(hidden = true) private String token;
	 * 
	 * public registerUser() { super(); }
	 * 
	 * public int getId() { return id; }
	 * 
	 * public void setId(int id) { this.id = id; }
	 * 
	 * public String getUsername() { return username; }
	 * 
	 * public void setUsername(String username) { this.username = username; }
	 * 
	 * public String getPassword() { return password; }
	 * 
	 * public void setPassword(String password) { this.password = password; }
	 * 
	 * public String getEmail() { return email; }
	 * 
	 * public void setEmail(String email) { this.email = email; }
	 * 
	 * public String getContactNo() { return contactNo; }
	 * 
	 * public void setContactNo(String contactNo) { this.contactNo = contactNo; }
	 * 
	 * public String getOrganization() { return organization; }
	 * 
	 * public void setOrganization(String organization) { this.organization =
	 * organization; }
	 * 
	 * public String getToken() { return token; }
	 * 
	 * public void setToken(String token) { this.token = token; }
	 * 
	 * @Override public String toString() { return "registerUser [id=" + id +
	 * ", username=" + username + ", password=" + password + ", email=" + email +
	 * ", contactNo=" + contactNo + ", organization=" + organization + ", token=" +
	 * token + "]"; }
	 */

		
}
