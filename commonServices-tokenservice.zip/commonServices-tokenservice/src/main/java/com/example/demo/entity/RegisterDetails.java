package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.PrePersist;
import javax.persistence.Table;

import io.swagger.annotations.ApiModelProperty;

@Entity
@Table(name = "registerUser")
public class RegisterDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	//@ApiModelProperty(hidden = true)
	@Column(unique = true)
	private int id;
	@Column(unique = true)
	private String username;
	private String password;
	@Column(unique = true)
	private String email;
	@Column(length = 10)
	private String contactNo;
	private String organization;
	private String fullname;
	@Column(nullable = false)
	private String role;
	@Column(columnDefinition = "TEXT")
	@ApiModelProperty(hidden = true)
	private String token;

	//set default value for role
	@PrePersist
	public void  prePersist() {
		if(role==null||role.isEmpty()) {
			role="user";
			
		}
	}
	
	public RegisterDetails() {
		super();
	}

	/*
	 * public registerDetails(String projectName, String applicationName,
	 * List<String> services, LocalDate startDate, LocalDate endDate) { super();
	 * this.projectName = projectName; this.applicationName = applicationName;
	 * this.services = services; this.startDate = startDate; this.endDate = endDate;
	 * }
	 * 
	 * public registerDetails(String projectName, String applicationName,
	 * List<String> services, LocalDate startDate, LocalDate endDate, String token)
	 * { super(); this.projectName = projectName; this.applicationName =
	 * applicationName; this.services = services; this.startDate = startDate;
	 * this.endDate = endDate; this.token = token; }
	 */
	
	public RegisterDetails(int id, String username, String password, String email, String contactNo,
			String organization, String fullname, String role) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.email = email;
		this.contactNo = contactNo;
		this.organization = organization;
		this.fullname = fullname;
		this.role = role;
	}

	public RegisterDetails(String username, String email) {
		super();
		this.username = username;
		this.email = email;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}	

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getOrganization() {
		return organization;
	}

	public void setOrganization(String organization) {
		this.organization = organization;
	}

	public String getFullname() {
		return fullname;
	}

	public String getRole() {
		return role;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "RegisterDetails [id=" + id + ", username=" + username + ", password=" + password + ", email=" + email
				+ ", contactNo=" + contactNo + ", organization=" + organization + ", fullname=" + fullname + ", role="
				+ role + ", token=" + token + "]";
	}

	

	
}
